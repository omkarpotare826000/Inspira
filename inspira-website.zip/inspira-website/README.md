# Inspira - Creative Digital Studio Website

A modern, responsive, single-page website built using HTML, CSS, and JavaScript.

## 🚀 Features
- Web, Marketing, and eCommerce services section
- Smooth scrolling & mobile responsiveness
- Team showcase & testimonials
- Tailwind CSS + Font Awesome
- Dark theme with animated effects

## 📦 Files
- `inspira.html` – Main HTML file
- `styles.css` – Custom styles
- `script.js` – Interactions and animations
- `Inspira.png` – Brand logo
- `replit.md` – Project documentation

## 🔗 Live Demo
[View the website](https://your-username.github.io/inspira-website/)

## 🛠 Tech Stack
- HTML5
- Tailwind CSS
- Vanilla JS
- GitHub Pages
